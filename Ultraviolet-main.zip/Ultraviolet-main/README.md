# Ultraviolet
This is a copy of the ultraviolet made by the Titanium network, I have customized it and linked other proxies on the page. This was made for the peeps on replit.
Copy this link, "https://github.com/LandonOrr/Ultraviolet/"

#Alternitive
Download the zip and upload to replit.

#DO NOT
Upload this and claim you created Ultraviolet or my version of Ultraviolet. As I will take down your website.

The original replit is: "https://ultraviolet-node.landonorr.repl.co/"
